﻿namespace ConvMVVM3.Core.DependencyInjection.Abstractions
{
    public enum ServiceLifetime
    {
        Singleton,
        Scoped,
        Transient
    }
}
