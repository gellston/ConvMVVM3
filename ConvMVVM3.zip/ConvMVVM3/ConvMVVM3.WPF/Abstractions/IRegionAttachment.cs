using System;

namespace ConvMVVM3.WPF.Abstractions
{
    public interface IRegionAttachment : IDisposable
    {
    }
}
